Analyzing point spread functions for multiple emitter fitting by posterior density estimation
Raymond van Dijk, Jelmer Cnossen, Dylan Kalisvaart, Carlas S. Smith

Collection of the synthetic data and ground truth parameters used for generating the paper and supplemental document figures. Saved using the save feature from the Numpy python package.
files are designated as follows:

 - smp: 		synthetic frames
 - pos: 		3D emitter position
 - I:  			emitter intensity
 - bg: 			background intensity
 - emitterState:	indicates which emitters are active per frame

Contained is the data for: the two emitter tests using astigmatic and biplane imaging, convergence and precision tests for astigmatic and tetrapod imaging, and multimodality and model accuracy tests for astigmatic and biplane imaging.
